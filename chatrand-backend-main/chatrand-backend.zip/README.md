# How to start 

## 1. npm install
## 2. npm run start:dev
