const EventEmitter = require('events');

const eventBus = new EventEmitter();

module.exports = {
  eventBus: eventBus,
};
